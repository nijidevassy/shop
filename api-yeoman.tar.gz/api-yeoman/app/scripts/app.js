'use strict';

/**
 * @ngdoc overview
 * @name apiYeomanApp
 * @description
 * # apiYeomanApp
 *
 * Main module of the application.
 */
angular
  .module('apiYeomanApp', [
    'ngMessages',
    'ngResource',
    'ui.router'
  ]);
